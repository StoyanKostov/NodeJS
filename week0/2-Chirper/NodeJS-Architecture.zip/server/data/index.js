'use strict';

var data = {};
data.users = require('./user-data');

module.exports = data;
